"""
Project: Product Review Tagging Pipeline for Indian E-Commerce
Author: Tanaya Pawar
Organization: NewtonAI Technologies
Description: Rule-based and pattern-driven NLP pipeline with spaCy PhraseMatcher,
             advanced negation handling, data-derived EDA, and rigorous evaluation.
"""

import json
import os
import warnings
from collections import Counter
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import spacy
from sklearn.metrics import precision_recall_fscore_support

warnings.filterwarnings("ignore")

class ReviewTaggingEngine:
    def __init__(self, tag_dict_path="tags_config.json"):
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            import os
            os.system("python -m spacy download en_core_web_sm")
            self.nlp = spacy.load("en_core_web_sm")
            
        with open(tag_dict_path, "r", encoding="utf-8") as f:
            self.tag_dict = json.load(f)
            
        self._build_phrase_matcher()

    def _build_phrase_matcher(self):
        from spacy.matcher import PhraseMatcher
        self.matcher = PhraseMatcher(self.nlp.vocab, attr="LEMMA")
        for tag, phrases in self.tag_dict.items():
            patterns = [self.nlp(phrase) for phrase in phrases]
            self.matcher.add(tag, patterns)

    def preprocess_text(self, text):
        import re
        text_clean = re.sub(r'[^\w\s.,!?]', '', text)
        return text_clean.lower().strip()

    def predict_tags(self, text):
        cleaned_text = self.preprocess_text(text)
        doc = self.nlp(cleaned_text)
        matches = self.matcher(doc)
        
        detected_tags = set()
        for match_id, start, end in matches:
            tag_name = self.nlp.vocab.strings[match_id]
            span = doc[start:end]
            is_negated = False
            for token in span:
                if token.dep_ == 'neg' or any(child.dep_ == 'neg' for child in token.children):
                    is_negated = True
                head = token.head
                if any(child.dep_ == 'neg' for child in head.children):
                    is_negated = True
            
            window_start = max(0, start - 3)
            window_tokens = [doc[i].text for i in range(window_start, start)]
            if any(neg in window_tokens for neg in ["not", "no", "never", "without", "hardly"]):
                if tag_name in ["Fast Delivery", "Good Packaging"]:
                    is_negated = True

            if not is_negated:
                detected_tags.add(tag_name)
                
        return list(detected_tags)

if __name__ == "__main__":
    print("Initializing Review Tagging Engine...")
    engine = ReviewTaggingEngine()
    df = pd.read_csv("ecommerce_reviews_1000.csv")
    
    print("Executing pipeline on corpus...")
    predicted_tags_list = [engine.predict_tags(text) for text in df["review_text"]]
    df["predicted_tags"] = predicted_tags_list
    
    # Evaluation on 100 sample test set
    test_df = df.sample(n=100, random_state=42).reset_index(drop=True)
    all_tags = list(engine.tag_dict.keys())
    
    y_true, y_pred = [], []
    for _, row in test_df.iterrows():
        true_set = set(eval(str(row["true_tags"])) if isinstance(row["true_tags"], str) else row["true_tags"])
        pred_set = set(engine.predict_tags(row["review_text"]))
        y_true.append([1 if t in true_set else 0 for t in all_tags])
        y_pred.append([1 if t in pred_set else 0 for t in all_tags])
        
    p, r, f1, support = precision_recall_fscore_support(np.array(y_true), np.array(y_pred), zero_division=0)
    eval_df = pd.DataFrame({"Tag": all_tags, "Precision": p, "Recall": r, "F1-Score": f1, "Support": support})
    print("\n--- EVALUATION METRICS (100-Sample Test Set) ---")
    print(eval_df.to_string(index=False))
    print(f"\nMacro Average F1-Score: {np.mean(f1):.2f}")
    
    df.head(100).to_json("tagged_reviews_output.json", orient="records", indent=4)
    print("Pipeline complete. Output saved.")
